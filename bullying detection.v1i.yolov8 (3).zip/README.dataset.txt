# bullying detection > 2024-02-13 11:13am
https://universe.roboflow.com/igejohn/bullying-detection-lixke

Provided by a Roboflow user
License: CC BY 4.0

